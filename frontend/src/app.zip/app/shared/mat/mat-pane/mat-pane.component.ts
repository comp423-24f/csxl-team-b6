import { Component } from '@angular/core';

@Component({
  selector: 'mat-pane',
  templateUrl: './mat-pane.component.html',
  styleUrl: './mat-pane.component.css'
})
export class MatPaneComponent {}
